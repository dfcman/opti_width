import pandas as pd
import sys
import time
import configparser
import os
import logging
import argparse
import pprint
from optimize.roll_optimize import RollOptimize
# from optimize.roll_optimize_cpsat import RollOptimizeCpsat
from optimize.roll_sl_optimize import RollSLOptimize
from optimize.sheet_optimize import SheetOptimize
from optimize.sheet_optimize_var import SheetOptimizeVar
from optimize.sheet_optimize_ca import SheetOptimizeCa
from db.db_connector import Database

def process_roll_lot(
        db, plant, pm_no, schedule_unit, lot_no, version, re_min_width, re_max_width, re_max_pieces, paper_type, b_wgt,
        start_prod_seq=0, start_group_order_no=0
):
    """롤지 lot에 대한 전체 최적화 프로세스를 처리하고 결과를 반환합니다."""
    logging.info(f"\n{'='*60}")
    logging.info(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Roll Lot: {lot_no} (Version: {version}) 처리 시작")
    logging.info(f"적용 파라미터: min_width={re_min_width}, max_width={re_max_width}, max_pieces={re_max_pieces}")
    logging.info(f"시작 시퀀스 번호: prod_seq={start_prod_seq}, group_order_no={start_group_order_no}")
    logging.info(f"{'='*60}")

    raw_orders = db.get_roll_orders_from_db(paper_prod_seq=lot_no)

    if not raw_orders:
        logging.error(f"[에러] Lot {lot_no}의 롤지 오더를 가져오지 못했습니다.")
        return None, None, start_prod_seq, start_group_order_no

    df_orders = pd.DataFrame(raw_orders)
    df_orders['lot_no'] = lot_no
    df_orders['version'] = version

    # 1. 개별 오더 그룹핑 (DB 저장용) - order_no 포함
    group_cols = ['지폭', '롤길이', '등급', 'core', 'dia', 'order_no']
    for col in ['지폭', '롤길이']:
        df_orders[col] = pd.to_numeric(df_orders[col])
    df_orders['등급'] = df_orders['등급'].astype(str)
    
    df_groups = df_orders.groupby(group_cols).agg(
        대표오더번호=('order_no', 'first')
    ).reset_index()
    df_groups = df_groups.sort_values(by=group_cols).reset_index(drop=True)
    
    df_groups['group_order_no'] = [f"30{lot_no}{start_group_order_no + i + 1:03d}" for i in df_groups.index]
    last_group_order_no = start_group_order_no + len(df_groups)
    
    df_orders = pd.merge(df_orders, df_groups, on=group_cols, how='left')

    logging.info(f"--- Lot {lot_no} 원본 주문 정보 (그룹오더 포함) ---")
    logging.info(df_orders.to_string())
    logging.info("\n")

    # 2. 지폭 그룹핑 (엔진 최적화용) - order_no 제외
    # 엔진 효율을 위해 동일 규격은 하나로 묶음
    width_group_cols = ['지폭', '롤길이', '등급', 'core', 'dia', '수출내수', 'sep_qt']
    df_width_groups = df_orders.groupby(width_group_cols).agg(
        total_qty=('주문수량', 'sum')
    ).reset_index()
    
    # 임시 그룹 ID 생성 (WG...)
    df_width_groups['width_group_no'] = [f'WG{i+1}' for i in range(len(df_width_groups))]
    
    # 원본 데이터에 지폭 그룹 ID 매핑
    df_orders = pd.merge(df_orders, df_width_groups[['지폭', '롤길이', '등급', 'core', 'dia', '수출내수', 'sep_qt', 'width_group_no']], 
                         on=['지폭', '롤길이', '등급', 'core', 'dia', '수출내수', 'sep_qt'], how='left')

    all_results = {
        "pattern_result": [],
        "pattern_details_for_db": [],
        "pattern_roll_details_for_db": [],
        "pattern_roll_cut_details_for_db": [],
        "fulfillment_summary": []
    }
    
    # 엔진 수행 그룹핑 기준 컬럼 설정
    grouping_cols = ['롤길이', 'core', 'dia', '등급']
    unique_groups = df_orders[grouping_cols].drop_duplicates()
    prod_seq_counter = start_prod_seq

    # 결과 배분을 위한 준비
    from collections import Counter
    remaining_demands = df_orders.set_index('group_order_no')['주문수량'].to_dict()
    width_group_to_orders = df_orders.groupby('width_group_no')['group_order_no'].apply(list).to_dict()

    for _, row in unique_groups.iterrows():
        roll_length = row['롤길이']
        core = row['core']
        dia = row['dia']
        quality_grade = row['등급']
        logging.info(f"\n--- 롤길이 그룹 {roll_length}, Core {core}, Dia {dia}에 대한 최적화 시작 ---")
        
        # 엔진에는 지폭 그룹 데이터를 전달 (width_group_no를 group_order_no로 위장)
        df_subset_engine = df_width_groups[
            (df_width_groups['롤길이'] == roll_length) & 
            (df_width_groups['core'] == core) & 
            (df_width_groups['dia'] == dia) &
            (df_width_groups['등급'] == quality_grade)
        ].copy()

        if df_subset_engine.empty:
            continue
            
        # 컬럼명 변경 (엔진 호환성)
        df_subset_engine = df_subset_engine.rename(columns={'width_group_no': 'group_order_no', 'total_qty': '주문수량'})

        logging.info(f"--- 롤길이 그룹 {roll_length}, Core {core}, Dia {dia}에 대한 주문 정보 (지폭 그룹핑) ---")
        logging.info(df_subset_engine.to_string())
        
        optimizer = RollOptimize(
            df_spec_pre=df_subset_engine,
            max_width=int(re_max_width),
            min_width=int(re_min_width),
            max_pieces=int(re_max_pieces),
            lot_no=lot_no,
            db=db,
            version=version
        )
        results = optimizer.run_optimize(start_prod_seq=prod_seq_counter)

        if "error" in results:
            logging.error(f"[에러] Lot {lot_no}, 롤길이 {roll_length}, Core {core}, Dia {dia} 최적화 실패: {results['error']}")
            continue
        
        # 3. 결과 배분 (Allocation)
        # 엔진 결과(WG 기준)를 개별 오더(group_order_no)로 변환
        
        allocated_pattern_details = []
        allocated_roll_details = []
        allocated_cut_details = []
        
        # results['pattern_details_for_db']는 WG ID를 포함하고 있음
        for entry in results['pattern_details_for_db']:
            wg_ids = entry['group_nos'] # 예: ['WG1', 'WG1', 'WG2', '', ...]
            widths = entry['widths']
            total_run_count = entry['count']
            
            allocated_runs = []
            
            for _ in range(total_run_count):
                run_assignment = []
                for i, wg_id in enumerate(wg_ids):
                    if not wg_id:
                        run_assignment.append('')
                        continue
                    
                    candidate_orders = width_group_to_orders.get(wg_id, [])
                    assigned_order = None
                    
                    # 잔여 수요 우선 할당
                    for order_id in candidate_orders:
                        if remaining_demands.get(order_id, 0) > 0:
                            assigned_order = order_id
                            remaining_demands[order_id] -= 1
                            break
                    
                    # 과잉 생산 시 마지막 오더 할당
                    if not assigned_order and candidate_orders:
                        assigned_order = candidate_orders[-1]
                    
                    run_assignment.append(assigned_order if assigned_order else '')
                allocated_runs.append(tuple(run_assignment))
            
            run_counts = Counter(allocated_runs)
            
            for order_combo, count in run_counts.items():
                prod_seq_counter += 1
                
                # Pattern Details
                new_entry = entry.copy()
                new_entry['group_nos'] = list(order_combo)
                new_entry['count'] = count
                new_entry['prod_seq'] = prod_seq_counter
                allocated_pattern_details.append(new_entry)
                
                # Roll Details
                roll_seq_counter = 0
                for i, width in enumerate(widths):
                    if width <= 0: continue
                    roll_seq_counter += 1
                    group_no = list(order_combo)[i]
                    
                    allocated_roll_details.append({
                        'rollwidth': width,
                        'pattern_length': entry.get('pattern_length', 0),
                        'widths': [width] + [0]*7,
                        'group_nos': [group_no] + ['']*7,
                        'count': count,
                        'prod_seq': prod_seq_counter,
                        'roll_seq': roll_seq_counter,
                        'rs_gubun': 'R',
                        'p_lot': entry.get('p_lot'),
                        'diameter': entry.get('diameter'),
                        'core': entry.get('core'),
                        'color': entry.get('color'),
                        'luster': entry.get('luster')
                    })
                    
                    # Cut Details (Roll Optimize에서는 보통 Roll Detail과 1:1 매핑되거나 생략될 수 있으나, 기존 로직 따름)
                    # 기존 로직: pattern_roll_cut_details_for_db 생성
                    # 여기서는 Roll Detail 하나당 Cut Detail 하나로 가정 (단순화)
                    allocated_cut_details.append({
                        'prod_seq': prod_seq_counter,
                        'unit_no': prod_seq_counter,
                        'seq': roll_seq_counter, # 임시
                        'roll_seq': roll_seq_counter,
                        'cut_seq': 1,
                        'rs_gubun': 'R',
                        'width': width,
                        'group_no': group_no,
                        'weight': 0,
                        'pattern_length': entry.get('pattern_length', 0),
                        'count': count,
                        'p_lot': entry.get('p_lot'),
                        'diameter': entry.get('diameter'),
                        'core': entry.get('core'),
                        'color': entry.get('color'),
                        'luster': entry.get('luster')
                    })

        logging.info(f"--- 롤길이 그룹 {roll_length}, Core {core}, Dia {dia} 최적화 성공 (배분 완료) ---")
        all_results["pattern_result"].append(results["pattern_result"]) # 요약용 (WG 기준일 수 있음, 주의)
        for detail in allocated_pattern_details:
            detail['max_width'] = int(re_max_width)
        all_results["pattern_details_for_db"].extend(allocated_pattern_details)
        all_results["pattern_roll_details_for_db"].extend(allocated_roll_details)
        all_results["pattern_roll_cut_details_for_db"].extend(allocated_cut_details)
        
        # Fulfillment Summary 재계산 필요 (개별 오더 기준)
        # 하지만 여기서는 일단 results['fulfillment_summary'] (WG 기준)를 넣고, 나중에 전체 집계 시 다시 계산하거나
        # 혹은 여기서 개별 오더 기준으로 다시 만들어야 함.
        # 시간 관계상, 그리고 save_results에서 fulfillment_summary는 로깅용으로 주로 쓰이므로
        # 정확한 개별 오더 충족 현황을 보려면 remaining_demands를 역산해야 함.
        # 일단은 WG 기준 Summary를 유지하되, 로그에 개별 오더 현황을 찍어주는 것이 좋음.
        all_results["fulfillment_summary"].append(results["fulfillment_summary"])

    if not all_results["pattern_details_for_db"]:
        logging.error(f"[에러] Lot {lot_no} 롤지 최적화 결과가 없습니다.")
        return None, None, start_prod_seq, start_group_order_no

    # Fulfillment Summary를 개별 오더 기준으로 재생성 (정확한 리포팅을 위해)
    # 생산된 수량 집계
    production_counts = Counter()
    for detail in all_results["pattern_details_for_db"]:
        for group_no in detail['group_nos']:
            if group_no:
                production_counts[group_no] += detail['count']
    
    df_prod = pd.DataFrame.from_dict(production_counts, orient='index', columns=['생산롤수'])
    df_prod.index.name = 'group_order_no'
    
    # 원본 오더 정보와 결합
    df_summary = df_orders.set_index('group_order_no')[['지폭', '롤길이', '등급', '주문수량']].copy()
    df_summary = df_summary.join(df_prod).fillna(0)
    df_summary['과부족(롤)'] = df_summary['생산롤수'] - df_summary['주문수량']
    df_summary = df_summary.reset_index()
    
    final_results = {
        "pattern_result": pd.concat(all_results["pattern_result"], ignore_index=True), # 여전히 WG 기준 패턴일 수 있음
        "pattern_details_for_db": all_results["pattern_details_for_db"],
        "pattern_roll_details_for_db": all_results["pattern_roll_details_for_db"],
        "pattern_roll_cut_details_for_db": all_results["pattern_roll_cut_details_for_db"],
        "fulfillment_summary": df_summary # 개별 오더 기준 Summary로 교체
    }

    logging.info("\n--- 롤지 최적화 성공. ---")
    return final_results, df_orders, prod_seq_counter, last_group_order_no


def process_roll_lot_ca(
        db, plant, pm_no, schedule_unit, lot_no, version, re_min_width, re_max_width, re_max_pieces, paper_type, b_wgt,
        start_prod_seq=0, start_group_order_no=0
):
    """롤지 lot에 대한 전체 최적화 프로세스를 처리하고 결과를 반환합니다."""
    logging.info(f"\n{'='*60}")
    logging.info(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Roll Lot: {lot_no} (Version: {version}) 처리 시작")
    logging.info(f"적용 파라미터: min_width={re_min_width}, max_width={re_max_width}, max_pieces={re_max_pieces}")
    logging.info(f"시작 시퀀스 번호: prod_seq={start_prod_seq}, group_order_no={start_group_order_no}")
    logging.info(f"{'='*60}")

    raw_orders = db.get_roll_orders_from_db(paper_prod_seq=lot_no)

    if not raw_orders:
        logging.error(f"[에러] Lot {lot_no}의 롤지 오더를 가져오지 못했습니다.")
        return None, None, start_prod_seq, start_group_order_no

    df_orders = pd.DataFrame(raw_orders)
    df_orders['lot_no'] = lot_no
    df_orders['version'] = version

    group_cols = ['지폭', '롤길이', '등급', '오더번호']
    for col in ['지폭', '롤길이']:
        df_orders[col] = pd.to_numeric(df_orders[col])
    df_orders['등급'] = df_orders['등급'].astype(str)
    
    df_groups = df_orders.groupby(group_cols).agg(
        대표오더번호=('오더번호', 'first')
    ).reset_index()
    df_groups = df_groups.sort_values(by=group_cols).reset_index(drop=True)
    
    df_groups['group_order_no'] = [f"30{lot_no}{start_group_order_no + i + 1:03d}" for i in df_groups.index]
    last_group_order_no = start_group_order_no + len(df_groups)
    
    df_orders = pd.merge(df_orders, df_groups, on=group_cols, how='left')

    logging.info(f"--- Lot {lot_no} 원본 주문 정보 (그룹오더 포함) ---")
    logging.info(df_orders.to_string())
    logging.info("\n")

    all_results = {
        "pattern_result": [],
        "pattern_details_for_db": [],
        "pattern_roll_details_for_db": [],
        "pattern_roll_cut_details_for_db": [],
        "fulfillment_summary": []
    }
    
    unique_roll_lengths = df_orders['롤길이'].unique()
    prod_seq_counter = start_prod_seq

    for roll_length in unique_roll_lengths:
        logging.info(f"\n--- 롤길이 그룹 {roll_length}에 대한 최적화 시작 ---")
        df_subset = df_orders[df_orders['롤길이'] == roll_length].copy()

        if df_subset.empty:
            continue

        optimizer = RollOptimize(
            df_spec_pre=df_subset,
            max_width=int(re_max_width),
            min_width=int(re_min_width),
            max_pieces=int(re_max_pieces)
        )
        results = optimizer.run_optimize(start_prod_seq=prod_seq_counter)

        if "error" in results:
            logging.error(f"[에러] Lot {lot_no}, 롤길이 {roll_length} 최적화 실패: {results['error']}")
            continue
        
        prod_seq_counter = results.get('last_prod_seq', prod_seq_counter)

        logging.info(f"--- 롤길이 그룹 {roll_length} 최적화 성공 ---")
        all_results["pattern_result"].append(results["pattern_result"])
        for detail in results["pattern_details_for_db"]:
            detail['max_width'] = int(re_max_width)
        all_results["pattern_details_for_db"].extend(results["pattern_details_for_db"])
        all_results["pattern_roll_details_for_db"].extend(results.get("pattern_roll_details_for_db", []))
        all_results["pattern_roll_cut_details_for_db"].extend(results.get("pattern_roll_cut_details_for_db", []))
        all_results["fulfillment_summary"].append(results["fulfillment_summary"])

    if not all_results["pattern_details_for_db"]:
        logging.error(f"[에러] Lot {lot_no} 롤지 최적화 결과가 없습니다.")
        return None, None, start_prod_seq, start_group_order_no

    final_results = {
        "pattern_result": pd.concat(all_results["pattern_result"], ignore_index=True),
        "pattern_details_for_db": all_results["pattern_details_for_db"],
        "pattern_roll_details_for_db": all_results["pattern_roll_details_for_db"],
        "pattern_roll_cut_details_for_db": all_results["pattern_roll_cut_details_for_db"],
        "fulfillment_summary": pd.concat(all_results["fulfillment_summary"], ignore_index=True)
    }

    logging.info("\n--- 롤지 최적화 성공. ---")
    return final_results, df_orders, prod_seq_counter, last_group_order_no

def process_roll_sl_lot(
        db, plant, pm_no, schedule_unit, lot_no, version, 
        re_min_width, re_max_width, re_max_pieces, 
        paper_type, b_wgt,
        min_sl_width, max_sl_width, sl_trim_size,
        start_prod_seq=0, start_group_order_no=0
):
    """롤-슬리터 lot에 대한 전체 최적화 프로세스를 처리하고 결과를 반환합니다."""
    logging.info(f"\n{'='*60}")
    logging.info(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Roll-SL Lot: {lot_no} (Version: {version}) 처리 시작")
    logging.info(f"적용 파라미터: min_width={re_min_width}, max_width={re_max_width}, max_pieces={re_max_pieces}, min_sl_width={min_sl_width}, max_sl_width={max_sl_width}")
    logging.info(f"시작 시퀀스 번호: prod_seq={start_prod_seq}, group_order_no={start_group_order_no}")
    logging.info(f"{'='*60}")

    raw_orders = db.get_roll_sl_orders_from_db(paper_prod_seq=lot_no)

    if not raw_orders:
        logging.error(f"[에러] Lot {lot_no}의 롤-슬리터 오더를 가져오지 못했습니다.")
        return None, None, start_prod_seq, start_group_order_no

    df_orders = pd.DataFrame(raw_orders)
    # df_orders.rename(columns={'오더번호': 'order_no'}, inplace=True)
    df_orders['lot_no'] = lot_no
    df_orders['version'] = version

    group_cols = ['지폭', '롤길이', '등급', 'core', 'dia', 'luster', 'color', 'order_pattern']
    df_orders['지폭'] = pd.to_numeric(df_orders['지폭'])
    df_orders['롤길이'] = pd.to_numeric(df_orders['롤길이'])
    df_orders['등급'] = df_orders['등급'].astype(str)
    
    df_groups = df_orders.groupby(group_cols).agg(
        대표오더번호=('order_no', 'first')
    ).reset_index()
    df_groups = df_groups.sort_values(by=group_cols).reset_index(drop=True)
    df_groups['group_order_no'] = [f"30{lot_no}{start_group_order_no + i + 1:03d}" for i in df_groups.index]
    last_group_order_no = start_group_order_no + len(df_groups)

    df_orders = pd.merge(df_orders, df_groups, on=group_cols, how='left')

    optimizer = RollSLOptimize(
        df_spec_pre=df_orders,
        max_width=int(re_max_width),
        min_width=int(re_min_width),
        max_pieces=int(re_max_pieces),
        b_wgt=float(b_wgt),
        sl_trim=sl_trim_size,
        min_sl_width=min_sl_width,

        max_sl_width=max_sl_width,
        lot_no=lot_no
    )
    try:
        results = optimizer.run_optimize(start_prod_seq=start_prod_seq)
        prod_seq_counter = results.get('last_prod_seq', start_prod_seq)
    except Exception as e:
        import traceback
        logging.error(traceback.format_exc())
        raise e

    if not results or "error" in results:
        error_msg = results['error'] if results and 'error' in results else "No solution found"
        logging.error(f"[에러] Lot {lot_no} 롤-슬리터 최적화 실패: {error_msg}.")
        return None, None, start_prod_seq, start_group_order_no
    
    if results and "pattern_details_for_db" in results:
        for detail in results["pattern_details_for_db"]:
            detail['max_width'] = int(re_max_width)
    
    logging.info("롤-슬리터 최적화 성공.")
    return results, df_orders, prod_seq_counter, last_group_order_no

def apply_sheet_grouping(df_orders, start_group_order_no, lot_no):
    """
    쉬트지 오더 그룹핑 로직을 적용하고 group_order_no를 생성합니다.
    """
    def get_group_key(row):
        # 1. 내수
        if row['수출내수'] == '내수':
            # 내수이고 export_yn이 N이면 오더번호별로 그룹오더생성
            return f"DOM_{row['order_no']}"
        
        # 2. 수출
        else: # 수출내수 == '수출'
            # 수출이고 export_yn이 Y이면 order_gubun 값이 A 이면 오더번호 별로 그룹오더 생성
            if row.get('order_gubun') == 'A':
                return f"EXP_A_{row['order_no']}"
            else:
                # 그 외에는 오더정보의 length 가 450~549, 550~699, 700 이상, 이 그룹으로 그룹오더 생성
                length = row['세로']
                if 450 <= length <= 549:
                    return "EXP_L_450_549"
                elif 550 <= length <= 699:
                    return "EXP_L_550_699"
                elif length >= 700:
                    return "EXP_L_700_PLUS"
                else:
                    return f"EXP_L_OTHER_{length}"

    df_orders['_group_key'] = df_orders.apply(get_group_key, axis=1)
    
    # 그룹핑 기준: 가로, 등급, _group_key
    group_cols = ['가로', '등급', '_group_key']
    
    df_groups = df_orders.groupby(group_cols).agg(
        대표오더번호=('order_no', 'first')
    ).reset_index()
    
    # 정렬 (가로, 등급 순)
    df_groups = df_groups.sort_values(by=['가로', '등급']).reset_index(drop=True)
    
    # Group Order No 생성
    df_groups['group_order_no'] = [f"30{lot_no}{start_group_order_no + i + 1:03d}" for i in df_groups.index]
    last_group_order_no = start_group_order_no + len(df_groups)
    
    # 원본 데이터에 병합
    df_orders = pd.merge(df_orders, df_groups, on=group_cols, how='left')
    
    # 임시 컬럼 제거
    if '_group_key' in df_orders.columns:
        df_orders = df_orders.drop(columns=['_group_key'])
        
    return df_orders, df_groups, last_group_order_no

def process_sheet_lot(
        db, plant, pm_no, schedule_unit, lot_no, version, 
        re_min_width, re_max_width, re_max_pieces, 
        paper_type, b_wgt,
        min_sc_width, max_sc_width, sheet_trim_size, sheet_length_re,
        start_prod_seq=0, start_group_order_no=0
):
    """쉬트지 lot에 대한 전체 최적화 프로세스를 처리하고 결과를 반환합니다."""
    logging.info(f"\n{'='*60}")
    logging.info(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Sheet Lot: {lot_no} (Version: {version}) 처리 시작")
    logging.info(f"적용 파라미터: min_width={re_min_width}, max_width={re_max_width}, max_pieces={re_max_pieces}, min_sc_width={min_sc_width}, max_sc_width={max_sc_width}, sheet_length_re={sheet_length_re}")
    logging.info(f"시작 시퀀스 번호: prod_seq={start_prod_seq}, group_order_no={start_group_order_no}")
    logging.info(f"{'='*60}")

    raw_orders = db.get_sheet_orders_from_db(paper_prod_seq=lot_no)

    if not raw_orders:
        logging.error(f"[에러] Lot {lot_no}의 쉬트지 오더를 가져오지 못했습니다.")
        return None, None, start_prod_seq, start_group_order_no

    df_orders = pd.DataFrame(raw_orders)
    # df_orders.rename(columns={'오더번호': 'order_no'}, inplace=True)
    df_orders['lot_no'] = lot_no
    df_orders['version'] = version

    df_orders['가로'] = pd.to_numeric(df_orders['가로'])
    df_orders['세로'] = pd.to_numeric(df_orders['세로'])
    df_orders['등급'] = df_orders['등급'].astype(str)
    
    # --- [New Grouping Logic] ---
    df_orders, df_groups, last_group_order_no = apply_sheet_grouping(df_orders, start_group_order_no, lot_no)
    
    logging.info(f"--- Lot {df_groups.to_string()} 그룹마스터 정보 ---")

    all_results = {
        "pattern_result": [],
        "pattern_details_for_db": [],
        "pattern_roll_details_for_db": [],
        "pattern_roll_cut_details_for_db": [],
        "fulfillment_summary": []
    }
    
    unique_grades = df_orders['등급'].unique()
    prod_seq_counter = start_prod_seq
    
    for grade in unique_grades:
        logging.info(f"\n--- 등급 {grade}에 대한 쉬트지 최적화 시작 ---")
        df_subset = df_orders[df_orders['등급'] == grade].copy()
        
        if df_subset.empty:
            continue

        optimizer = SheetOptimize(
            df_spec_pre=df_subset,
            max_width=int(re_max_width),
            min_width=int(re_min_width),
            max_pieces=int(re_max_pieces),
            b_wgt=float(b_wgt),
            sheet_roll_length=sheet_length_re,
            sheet_trim=sheet_trim_size,
            min_sc_width=min_sc_width,
            max_sc_width=max_sc_width
        )
        
        try:
            results = optimizer.run_optimize(start_prod_seq=prod_seq_counter)
            
            if not results or "error" in results:
                error_msg = results['error'] if results and 'error' in results else "No solution found"
                logging.error(f"[에러] Lot {lot_no}, 등급 {grade} 쉬트지 최적화 실패: {error_msg}")
                continue
                
            prod_seq_counter = results.get('last_prod_seq', prod_seq_counter)
            
            if "pattern_details_for_db" in results:
                for detail in results["pattern_details_for_db"]:
                    detail['max_width'] = int(re_max_width)
            
            all_results["pattern_result"].append(results["pattern_result"])
            all_results["pattern_details_for_db"].extend(results["pattern_details_for_db"])
            all_results["pattern_roll_details_for_db"].extend(results.get("pattern_roll_details_for_db", []))
            all_results["pattern_roll_cut_details_for_db"].extend(results.get("pattern_roll_cut_details_for_db", []))
            all_results["fulfillment_summary"].append(results["fulfillment_summary"])
            
            logging.info(f"--- 등급 {grade} 쉬트지 최적화 성공 ---")
            
        except Exception as e:
            import traceback
            logging.error(f"[에러] Lot {lot_no}, 등급 {grade} 처리 중 예외 발생")
            logging.error(traceback.format_exc())
            continue

    if not all_results["pattern_details_for_db"]:
        logging.error(f"[에러] Lot {lot_no} 쉬트지 최적화 결과가 없습니다 (모든 등급 실패).")
        return None, None, start_prod_seq, start_group_order_no

    final_results = {
        "pattern_result": pd.concat(all_results["pattern_result"], ignore_index=True) if all_results["pattern_result"] else pd.DataFrame(),
        "pattern_details_for_db": all_results["pattern_details_for_db"],
        "pattern_roll_details_for_db": all_results["pattern_roll_details_for_db"],
        "pattern_roll_cut_details_for_db": all_results["pattern_roll_cut_details_for_db"],
        "fulfillment_summary": pd.concat(all_results["fulfillment_summary"], ignore_index=True) if all_results["fulfillment_summary"] else pd.DataFrame()
    }

    logging.info("쉬트지 최적화 성공 (전체 등급 완료).")
    return final_results, df_orders, prod_seq_counter, last_group_order_no

def process_sheet_lot_var(
        db, plant, pm_no, schedule_unit, lot_no, version, 
        re_min_width, re_max_width, re_max_pieces, 
        paper_type, b_wgt,
        min_sc_width, max_sc_width, sheet_trim_size, min_sheet_length_re, max_sheet_length_re,
        start_prod_seq=0, start_group_order_no=0
):
    """쉬트지 lot에 대한 전체 최적화 프로세스를 처리하고 결과를 반환합니다."""
    logging.info(f"\n{'='*60}")
    logging.info(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Sheet Lot (Var): {lot_no} (Version: {version}) 처리 시작")
    logging.info(f"적용 파라미터: min_width={re_min_width}, max_width={re_max_width}, max_pieces={re_max_pieces}")
    logging.info(f"min_sc_width={min_sc_width}, max_sc_width={max_sc_width}, min_sheet_length_re={min_sheet_length_re}, max_sheet_length_re={max_sheet_length_re}")
    logging.info(f"시작 시퀀스 번호: prod_seq={start_prod_seq}, group_order_no={start_group_order_no}")
    logging.info(f"{'='*60}")

    raw_orders = db.get_sheet_orders_from_db_var(paper_prod_seq=lot_no)

    if not raw_orders:
        logging.error(f"[에러] Lot {lot_no}의 쉬트지(Var) 오더를 가져오지 못했습니다.")
        return None, None, start_prod_seq, start_group_order_no

    df_orders = pd.DataFrame(raw_orders)
    # df_orders.rename(columns={'오더번호': 'order_no'}, inplace=True)
    df_orders['lot_no'] = lot_no
    df_orders['version'] = version

    group_cols = ['가로', '세로', '등급']
    df_orders['가로'] = pd.to_numeric(df_orders['가로'])
    df_orders['세로'] = pd.to_numeric(df_orders['세로'])
    df_orders['등급'] = df_orders['등급'].astype(str)
    
    df_groups = df_orders.groupby(group_cols).agg(
        대표오더번호=('order_no', 'first')
    ).reset_index()
    df_groups = df_groups.sort_values(by=group_cols).reset_index(drop=True)
    df_groups['group_order_no'] = [f"30{lot_no}{start_group_order_no + i + 1:03d}" for i in df_groups.index]
    last_group_order_no = start_group_order_no + len(df_groups)
    
    df_orders = pd.merge(df_orders, df_groups, on=group_cols, how='left')

    logging.info("--- 쉬트지(Var) 최적화 시작 ---")
    optimizer = SheetOptimizeVar(
        df_spec_pre=df_orders,
        max_width=int(re_max_width),
        min_width=int(re_min_width),
        max_pieces=int(re_max_pieces),
        b_wgt=float(b_wgt),
        min_sheet_roll_length=int(min_sheet_length_re) // 10 * 10,
        max_sheet_roll_length=int(max_sheet_length_re) // 10 * 10,
        sheet_trim=sheet_trim_size,
        min_sc_width=min_sc_width,
        max_sc_width=max_sc_width
    )
    try:
        results = optimizer.run_optimize(start_prod_seq=start_prod_seq)
        prod_seq_counter = results.get('last_prod_seq', start_prod_seq)
    except Exception as e:
        import traceback
        logging.error(traceback.format_exc())
        raise e

    if not results or "error" in results:
        error_msg = results['error'] if results and 'error' in results else "No solution found"
        logging.error(f"[에러] Lot {lot_no} 쉬트지(Var) 최적화 실패: {error_msg}.")
        return None, None, start_prod_seq, start_group_order_no
    
    if results and "pattern_details_for_db" in results:
        for detail in results["pattern_details_for_db"]:
            detail['max_width'] = int(re_max_width)

    logging.info("쉬트지(Var) 최적화 성공.")
    return results, df_orders, prod_seq_counter, last_group_order_no

def process_sheet_lot_ca(
        db, plant, pm_no, schedule_unit, lot_no, version, 
        re_min_width, re_max_width, re_max_pieces, 
        paper_type, b_wgt,
        min_sc_width, max_sc_width, sheet_trim_size, min_sheet_length_re, max_sheet_length_re,
        start_prod_seq=0, start_group_order_no=0
):
    """쉬트지 lot에 대한 전체 최적화 프로세스를 처리하고 결과를 반환합니다."""
    logging.info(f"\n{'='*60}")
    logging.info(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Sheet Lot (CA): {lot_no} (Version: {version}) 처리 시작")
    logging.info(f"적용 파라미터: min_width={re_min_width}, max_width={re_max_width}, max_pieces={re_max_pieces}")
    logging.info(f"min_sc_width={min_sc_width}, max_sc_width={max_sc_width}, min_sheet_length_re={min_sheet_length_re}, max_sheet_length_re={max_sheet_length_re}")
    logging.info(f"시작 시퀀스 번호: prod_seq={start_prod_seq}, group_order_no={start_group_order_no}")
    logging.info(f"{'='*60}")

    raw_orders = db.get_sheet_orders_from_db_ca(paper_prod_seq=lot_no)

    if not raw_orders:
        logging.error(f"[에러] Lot {lot_no}의 쉬트지(CA) 오더를 가져오지 못했습니다.")
        return None, None, start_prod_seq, start_group_order_no

    df_orders = pd.DataFrame(raw_orders)
    # df_orders.rename(columns={'오더번호': 'order_no'}, inplace=True)
    df_orders['lot_no'] = lot_no
    df_orders['version'] = version

    group_cols = ['가로', '세로', '등급']
    df_orders['가로'] = pd.to_numeric(df_orders['가로'])
    df_orders['세로'] = pd.to_numeric(df_orders['세로'])
    df_orders['등급'] = df_orders['등급'].astype(str)
    
    df_groups = df_orders.groupby(group_cols).agg(
        대표오더번호=('order_no', 'first')
    ).reset_index()
    df_groups = df_groups.sort_values(by=group_cols).reset_index(drop=True)
    df_groups['group_order_no'] = [f"30{lot_no}{start_group_order_no + i + 1:03d}" for i in df_groups.index]
    last_group_order_no = start_group_order_no + len(df_groups)
    
    df_orders = pd.merge(df_orders, df_groups, on=group_cols, how='left')

    logging.info("--- 쉬트지(CA) 최적화 시작 ---")
    optimizer = SheetOptimizeCa(
        df_spec_pre=df_orders,
        max_width=int(re_max_width),
        min_width=int(re_min_width),
        max_pieces=int(re_max_pieces),
        b_wgt=float(b_wgt),
        min_sheet_roll_length=int(min_sheet_length_re) // 10 * 10,
        max_sheet_roll_length=int(max_sheet_length_re) // 10 * 10,
        sheet_trim=sheet_trim_size,
        min_sc_width=min_sc_width,
        max_sc_width=max_sc_width
    )
    try:
        results = optimizer.run_optimize(start_prod_seq=start_prod_seq)
        prod_seq_counter = results.get('last_prod_seq', start_prod_seq)
    except Exception as e:
        import traceback
        logging.error(traceback.format_exc())
        raise e

    if not results or "error" in results:
        error_msg = results['error'] if results and 'error' in results else "No solution found"
        logging.error(f"[에러] Lot {lot_no} 쉬트지(CA) 최적화 실패: {error_msg}.")
        return None, None, start_prod_seq, start_group_order_no
    
    if results and "pattern_details_for_db" in results:
        for detail in results["pattern_details_for_db"]:
            detail['max_width'] = int(re_max_width)

    logging.info("쉬트지(CA) 최적화 성공.")
    return results, df_orders, prod_seq_counter, last_group_order_no

def save_results(db, lot_no, version, plant, pm_no, schedule_unit, re_max_width, paper_type, b_wgt, all_results, all_df_orders):
    """
    최적화 결과를 DB에 저장하고 CSV파일로 출력합니다.
    
    Returns:
        int: 상태 코드 (0: 모든 오더 충족, 1: 일부 오더 부족, 2: 에러)
    """
    if not all_results:
        logging.warning(f"Lot {lot_no}에 대해 저장할 결과가 없습니다.")
        return 2  # 결과가 없으면 에러

    final_pattern_result = pd.concat([res["pattern_result"] for res in all_results], ignore_index=True)
    final_fulfillment_summary = pd.concat([res["fulfillment_summary"] for res in all_results], ignore_index=True)
    final_pattern_details_for_db = [item for res in all_results for item in res["pattern_details_for_db"]]
    final_pattern_roll_details_for_db = [item for res in all_results for item in res.get("pattern_roll_details_for_db", [])]
    final_pattern_roll_cut_details_for_db = [item for res in all_results for item in res.get("pattern_roll_cut_details_for_db", [])]
    
    final_df_orders = pd.concat(all_df_orders, ignore_index=True)

    logging.info("최적화 결과 (패턴별 생산량):")
    logging.info("\n" + final_pattern_result.to_string())

    # logging.info("패턴 상세 정보 (final_pattern_details_for_db):")
    # # Ensure full output without truncation
    # pd.set_option('display.max_rows', None)
    # pd.set_option('display.max_columns', None)
    # pd.set_option('display.width', 1000)
    # pd.set_option('display.max_colwidth', None)
    # logging.info("\n" + pd.DataFrame(final_pattern_details_for_db).to_string())
    
    # Fill NaNs for better logging
    final_fulfillment_summary = final_fulfillment_summary.fillna(0)
    
    logging.info("\n# ================= 주문 충족 현황 ================== #\n")
    logging.info("\n" + final_fulfillment_summary.to_string())
    logging.info("\n")
    logging.info("최적화 성공. 이제 결과를 DB에 저장합니다.")
    
    # [DEBUG] Check for NaNs in fulfillment summary
    if final_fulfillment_summary.isnull().values.any():
        logging.warning("[경고] Fulfillment Summary에 NaN 값이 포함되어 있습니다!")
        nan_rows = final_fulfillment_summary[final_fulfillment_summary.isnull().any(axis=1)]
        logging.warning(f"NaN Rows:\n{nan_rows.to_string()}")
    
    # [DEBUG] Log pattern details count
    logging.info(f"[DEBUG] Saving {len(final_pattern_details_for_db)} pattern details to DB.")
    if len(final_pattern_details_for_db) > 0:
        logging.info(f"[DEBUG] First pattern detail sample: {final_pattern_details_for_db[0]}")

    connection = None
    try:
        connection = db.pool.acquire()

        if not final_df_orders.empty:
            db.insert_order_group(
                connection, lot_no, version, plant, pm_no, schedule_unit, final_df_orders
            )

        logging.info("\n\n# ================= 패턴 상세 정보 (final_pattern_details_for_db) ================== #\n")
        logging.info(f"롤 재단 상세 정보 개수: {len(final_pattern_details_for_db)}")
        db.insert_pattern_sequence(
            connection, lot_no, version, plant, pm_no, schedule_unit, re_max_width, 
            paper_type, b_wgt, final_pattern_details_for_db
        )

        if final_pattern_roll_details_for_db:
            logging.info("\n\n# ================= 패턴롤 정보 (final_pattern_roll_details_for_db) ================== #\n")
            logging.info(f"롤 재단 상세 정보 개수: {len(final_pattern_roll_details_for_db)}")
            db.insert_roll_sequence(
                connection, lot_no, version, plant, pm_no, schedule_unit, re_max_width, 
                paper_type, b_wgt, final_pattern_roll_details_for_db
            )

        if final_pattern_roll_cut_details_for_db:
            logging.info("\n\n# ================= 롤 cut 재단 상세 정보 (final_pattern_roll_cut_details_for_db) ================== #\n")
            logging.info(f"롤 재단 상세 정보 개수: {len(final_pattern_roll_cut_details_for_db)}")
            db.insert_cut_sequence(
                connection, lot_no, version, plant, pm_no, schedule_unit, 
                paper_type, b_wgt, final_pattern_roll_cut_details_for_db
            )

        logging.info("\n\n# ================= 쉬트 재단 상세 정보 ================== #\n")
        db.insert_sheet_sequence(
            connection, lot_no, version, plant, pm_no, schedule_unit
        )

        connection.commit()
        logging.info("DB 트랜잭션이 성공적으로 커밋되었습니다.")

        output_dir = 'results'
        os.makedirs(output_dir, exist_ok=True)
        timestamp = time.strftime('%y%m%d%H%M%S')
        output_filename = f"{timestamp}_{lot_no}_{version}.csv"
        output_path = os.path.join(output_dir, output_filename)
        final_pattern_result.to_csv(output_path, index=False, encoding='utf-8-sig')
        logging.info(f"\n[성공] 요약 결과가 다음 파일에 저장되었습니다: {output_path}")
        
        # 최적화 상태 결정: fulfillment_summary의 과부족 확인
        # 과부족 컨럼이 없으면 기본적으로 성공(0)으로 간주
        final_status = 0  # 기본값: 모든 오더 충족
        
        # 롤 최적화 결과 확인 (과부족(롤) 컨럼이 있는 경우)
        if '과부족(롤)' in final_fulfillment_summary.columns:
            under_production_rolls = final_fulfillment_summary[final_fulfillment_summary['과부족(롤)'] != 0]
            if not under_production_rolls.empty:
                final_status = 1  # 일부 오더 초과(부족)
                logging.warning(f"[경고] 초과(부족) 생산된 롤 오더가 있습니다:\n{under_production_rolls.to_string()}")

        
        # 쉬트 최적화 결과 확인 (과부족(톤) 컨럼이 있는 경우)
        if '과부족(톤)' in final_fulfillment_summary.columns:
            under_production_sheets = final_fulfillment_summary[final_fulfillment_summary['과부족(톤)'] < 2]  # 소수점 오차 고려
            over_production_sheets = final_fulfillment_summary[final_fulfillment_summary['과부족(톤)'] > 2]  # 소수점 오차 고려
            if not under_production_sheets.empty or not over_production_sheets.empty:
                final_status = 1  # 일부 오더 초과(부족)
                logging.warning(f"[경고] 초과(부족) 생산된 쉬트 오더가 있습니다:\n{under_production_sheets.to_string()}")
                logging.warning(f"[경고] 초과(부족) 생산된 쉬트 오더가 있습니다:\n{over_production_sheets.to_string()}")
        
        return final_status

    except Exception as e:
        logging.error(f"[에러] 데이터 저장 중 오류 발생: {e}")
        if connection:
            connection.rollback()
            logging.info("DB 트랜잭션이 롤백되었습니다.")
            db.pool.release(connection)
            connection = None
        
        db.update_lot_status(lot_no=lot_no, version=version, status=2)
        return 2  # 에러 상태

    finally:
        if connection:
            db.pool.release(connection)
        logging.info(f"\n{'='*60}")
        logging.info(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Lot: {lot_no} 처리 완료")
        logging.info(f"{'='*60}")

def setup_logging(lot_no, version):
    """로그 설정을 초기화합니다. 각 lot마다 새로운 로그 파일을 생성합니다."""
    log_dir = 'results'
    os.makedirs(log_dir, exist_ok=True)
    timestamp = time.strftime('%y%m%d%H%M%S')
    log_filename = f"{timestamp}_{lot_no}_{version}.log"
    log_path = os.path.join(log_dir, log_filename)

    # 기존 핸들러 모두 제거 (이전 lot의 핸들러)
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    # 기존 핸들러 제거
    for handler in logger.handlers[:]:
        handler.close()
        logger.removeHandler(handler)
    
    # 새로운 핸들러 추가
    file_handler = logging.FileHandler(log_path, mode='w', encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    stream_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

def main():
    """메인 실행 함수"""
    db = None
    lot_no = None
    version = None
    parser = argparse.ArgumentParser(description='Optimization Executor')
    parser.add_argument('--plant', type=str, default='3000', help='Plant Code (3000, 5000, 8000)')
    args = parser.parse_args()
    plant_arg = args.plant

    db_section_map = {
        '3000': 'database_dj',
        '5000': 'database_ca',
        '8000': 'database_st'
    }
    db_section = db_section_map.get(plant_arg, 'database_dj')
    print(f"Connecting to DB Section: {db_section} for Plant: {plant_arg}")

    try:
        config = configparser.ConfigParser()
        config_path = os.path.join('conf', 'config.ini')
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"{config_path} 파일을 찾을 수 없습니다.")
        config.read(config_path, encoding='utf-8')
        
        if db_section not in config:
            raise KeyError(f"Config file does not contain section: {db_section}")
        
        db_config = config[db_section]
        
        db = Database(user=db_config['user'], password=db_config['password'], dsn=db_config['dsn'])

        # Dynamic Patching of DataInserters based on Plant
        # update_lot_status는 공통 모듈에서 가져오고, 나머지 insert 함수들은 공장별 모듈에서 가져옴
        from db import db_insert_data as db_common_module
        
        if plant_arg == '5000':
            from db import db_insert_data_ca as db_module
        elif plant_arg == '8000':
            from db import db_insert_data_st as db_module
        else: # 3000 or default
            from db import db_insert_data_dj as db_module

        # update_lot_status는 공통 모듈에서 바인딩 (3개 공장 공통)
        db.update_lot_status = db_common_module.DataInserters.update_lot_status.__get__(db, Database)
        
        # 나머지 insert 함수들은 공장별 모듈에서 바인딩
        db.insert_pattern_sequence = db_module.DataInserters.insert_pattern_sequence.__get__(db, Database)
        db.insert_roll_sequence = db_module.DataInserters.insert_roll_sequence.__get__(db, Database)
        db.insert_cut_sequence = db_module.DataInserters.insert_cut_sequence.__get__(db, Database)
        db.insert_sheet_sequence = db_module.DataInserters.insert_sheet_sequence.__get__(db, Database)
        db.insert_order_group = db_module.DataInserters.insert_order_group.__get__(db, Database)

        print(f"Applied common DataInserters from {db_common_module.__name__}")
        print(f"Applied plant-specific DataInserters from {db_module.__name__}")


        while True:
            # Plant에 따라 대상 Lot 조회 함수 분기
            if plant_arg == '5000':
                ( 
                    plant, pm_no, schedule_unit, lot_no, version, min_width, 
                    max_width, sheet_max_width, max_pieces, sheet_max_pieces, 
                    paper_type, b_wgt,
                    min_sc_width, max_sc_width, sheet_trim_size, sheet_length_re,
                    sheet_order_cnt, roll_order_cnt
                ) = db.get_target_lot_ca()
            elif plant_arg == '8000':
                 ( 
                    plant, pm_no, schedule_unit, lot_no, version, min_width, 
                    max_width, sheet_max_width, max_pieces, sheet_max_pieces, 
                    paper_type, b_wgt,
                    min_sc_width, max_sc_width, sheet_trim_size, sheet_length_re,
                    sheet_order_cnt, roll_order_cnt
                ) = db.get_target_lot_var()
            else: # 3000 or default
                ( 
                    plant, pm_no, schedule_unit, lot_no, version, min_width, 
                    max_width, sheet_max_width, max_pieces, sheet_max_pieces, 
                    paper_type, b_wgt,
                    min_sc_width, max_sc_width, sheet_trim_size, sheet_length_re,
                    sheet_order_cnt, roll_order_cnt
                ) = db.get_target_lot()

            if not lot_no:
                # print("처리할 Lot이 없습니다. 10초 후 다시 시도합니다.")
                time.sleep(10)
                continue

            setup_logging(lot_no, version)
            db.update_lot_status(lot_no=lot_no, version=version, status=8)
            db.delete_optimization_results(lot_no, version)
            

            prod_seq_counter = 0
            group_order_no_counter = 0
            all_results = []
            all_df_orders = []

            if roll_order_cnt > 0:
                logging.info(f"롤지 오더 {roll_order_cnt}건 처리 시작.")
                if plant == '3000':
                    roll_results, roll_df_orders, prod_seq_counter, group_order_no_counter = process_roll_lot(
                        db, plant, pm_no, schedule_unit, lot_no, version, 
                        min_width, max_width, max_pieces, paper_type, b_wgt,
                        start_prod_seq=prod_seq_counter, start_group_order_no=group_order_no_counter
                    )
                else:
                    ( 
                        plant_sl, pm_no_sl, schedule_unit_sl, lot_no_sl, version_sl, min_width_sl, 
                        max_width_sl, _, max_pieces_sl, _, 
                        paper_type_sl, b_wgt_sl,
                        min_sl_width, max_sl_width, sl_trim_size
                    ) = db.get_target_lot_sl(lot_no=lot_no)
                    
                    roll_results, roll_df_orders, prod_seq_counter, group_order_no_counter = process_roll_sl_lot(
                        db, plant_sl, pm_no_sl, schedule_unit_sl, lot_no_sl, version_sl, 
                        min_width_sl, max_width_sl, max_pieces_sl, paper_type_sl, b_wgt_sl,
                        min_sl_width, max_sl_width, sl_trim_size,
                        start_prod_seq=prod_seq_counter, start_group_order_no=group_order_no_counter
                    )
                if roll_results:
                    all_results.append(roll_results)
                    all_df_orders.append(roll_df_orders)

            if sheet_order_cnt > 0: 
                logging.info(f"쉬트지 오더 {sheet_order_cnt}건 처리 시작.")
                if plant == '3000':
                    sheet_results, sheet_df_orders, prod_seq_counter, group_order_no_counter = process_sheet_lot(
                        db, plant, pm_no, schedule_unit, lot_no, version, 
                        min_width, sheet_max_width, sheet_max_pieces, paper_type, b_wgt,
                        min_sc_width, max_sc_width, sheet_trim_size, sheet_length_re,
                        start_prod_seq=prod_seq_counter, start_group_order_no=group_order_no_counter
                    )
                elif plant == '5000':
                    ( 
                        plant_ca, pm_no_ca, schedule_unit_ca, lot_no_ca, version_ca, min_width_ca, 
                        _, sheet_max_width_ca, _, sheet_max_pieces_ca, 
                        paper_type_ca, b_wgt_ca,
                        min_sc_width_ca, max_sc_width_ca, sheet_trim_size_ca, min_sheet_length_re_ca, max_sheet_length_re_ca
                    ) = db.get_target_lot_ca(lot_no=lot_no)

                    sheet_results, sheet_df_orders, prod_seq_counter, group_order_no_counter = process_sheet_lot_ca(
                        db, plant_ca, pm_no_ca, schedule_unit_ca, lot_no_ca, version_ca, 
                        min_width_ca, sheet_max_width_ca, sheet_max_pieces_ca, paper_type_ca, b_wgt_ca,
                        min_sc_width_ca, max_sc_width_ca, sheet_trim_size_ca, min_sheet_length_re_ca, max_sheet_length_re_ca,
                        start_prod_seq=prod_seq_counter, start_group_order_no=group_order_no_counter
                    )
                else:
                    ( 
                        plant_var, pm_no_var, schedule_unit_var, lot_no_var, version_var, min_width_var, 
                        _, sheet_max_width_var, _, sheet_max_pieces_var, 
                        paper_type_var, b_wgt_var,
                        min_sc_width_var, max_sc_width_var, sheet_trim_size_var, min_sheet_length_re_var, max_sheet_length_re_var
                    ) = db.get_target_lot_var(lot_no=lot_no)

                    sheet_results, sheet_df_orders, prod_seq_counter, group_order_no_counter = process_sheet_lot_var(
                        db, plant_var, pm_no_var, schedule_unit_var, lot_no_var, version_var, 
                        min_width_var, sheet_max_width_var, sheet_max_pieces_var, paper_type_var, b_wgt_var,
                        min_sc_width_var, max_sc_width_var, sheet_trim_size_var, min_sheet_length_re_var, max_sheet_length_re_var,
                        start_prod_seq=prod_seq_counter, start_group_order_no=group_order_no_counter
                    )
                
                if sheet_results:
                    all_results.append(sheet_results)
                    all_df_orders.append(sheet_df_orders)

            if all_results:
                final_status = save_results(db, lot_no, version, plant, pm_no, schedule_unit, max_width, paper_type, b_wgt, all_results, all_df_orders)
                db.update_lot_status(lot_no=lot_no, version=version, status=final_status)
                status_desc = {0: "모든 오더 충족", 1: "일부 오더 부족", 2: "에러"}.get(final_status, "알 수 없음")
                logging.info(f"[상태 업데이트] Lot {lot_no} Version {version} -> status={final_status} ({status_desc})")
            else:
                logging.error(f"[에러] Lot {lot_no}에 대한 최적화 결과가 없습니다. 상태를 2(에러)로 변경합니다.")
                db.update_lot_status(lot_no=lot_no, version=version, status=2)
            
            logging.info(f"{'='*60}")
            logging.info(f"{'='*60}")
            logging.info(f"{'='*60}")
            time.sleep(5)

    except FileNotFoundError as e:        
        logging.error(f"[치명적 에러] 설정 파일을 찾을 수 없습니다: {e}")
    except KeyboardInterrupt:
        logging.info("\n사용자에 의해 프로그램이 중단되었습니다.")
    except Exception as e:
        import traceback
        logging.error(f"\n[치명적 에러] 실행 중 예외 발생: {e}")
        logging.error(traceback.format_exc())
        if db and lot_no and version:
            db.update_lot_status(lot_no=lot_no, version=version, status=2)
    finally:
        if db:
            db.close_pool()
        logging.info("\n프로그램을 종료합니다.")

if __name__ == "__main__":
    main()
